package com.sh.onezip.productanswer.repository;

import com.sh.onezip.productanswer.entity.ProductAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductAnswerRepository extends JpaRepository<ProductAnswer, Long> {
}
