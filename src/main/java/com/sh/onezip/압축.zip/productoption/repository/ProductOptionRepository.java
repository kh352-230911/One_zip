package com.sh.onezip.productoption.repository;

import com.sh.onezip.productoption.entity.ProductOption;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductOptionRepository extends JpaRepository<ProductOption, Long> {
}
