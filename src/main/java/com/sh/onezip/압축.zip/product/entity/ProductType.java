package com.sh.onezip.product.entity;

public enum ProductType {
    // 식품
    O,
    // 가구
    U;
}
