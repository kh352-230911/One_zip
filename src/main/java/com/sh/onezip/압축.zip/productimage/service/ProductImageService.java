package com.sh.onezip.productimage.service;

import org.springframework.stereotype.Service;

@Service
public class ProductImageService {
}
