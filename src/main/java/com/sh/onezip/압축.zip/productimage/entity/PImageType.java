package com.sh.onezip.productimage.entity;

public enum PImageType {
    // 대표 이미지
    P,
    // 기본 이미지
    D;
}
