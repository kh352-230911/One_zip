package com.sh.onezip.businessmember.entity;

public enum BizAccess {

    // 사업자 승인 상태
    A,
    // 사업자 승인 거절 상태
    D;
}
