package com.sh.onezip.businessmember.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BusinessmemberController {

}
